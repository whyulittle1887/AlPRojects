// Author: A00291769
// Date: 30/10/21
// Code 1 Exam

package postgrad.oop1.code1;

public interface NewsMedia
{
    public String getName();
    public String getEditor();
}

interface QualityJournalism {}