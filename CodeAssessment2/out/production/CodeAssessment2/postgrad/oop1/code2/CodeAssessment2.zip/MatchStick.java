package postgrad.oop1.code2;

// Student ID: A00291769
// 27/11/21
// Code #2 Assessment

public interface MatchStick
{
    String matchHeadIngredients();
}
